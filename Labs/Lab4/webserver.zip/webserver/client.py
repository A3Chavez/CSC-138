from socket import *
from time import sleep
import sys

#Prepare the client socket
serverName = '10.0.0.236'
serverPort = 12003
clientSocket = socket(AF_INET, SOCK_STREAM)

#Try 3-Way Handshake
try:
	clientSocket.connect((serverName, serverPort))
except:
	print("Server is currently busy or offline. Please try again later.")
	clientSocket.close()
	sys.exit()
print("Connection Established.")

#Ask User for a file
fileName = input("Please enter the file you wish to request: ")

#Send HTTP request
request = "GET /" + fileName + " HTTP/1.1\r\n"
clientSocket.send(request.encode())
print("HTTP request was sent.")

#Receiving HTTP response
print("Server Response:\r\n")
data = ""
while True:
	newData = clientSocket.recv(1024).decode()
	data += newData
	if(len(newData) == 0):
		break
print(data)

#Close client socket and end program
print("Closing socket ", end = " ", flush = True)
sleep(.5)
print (". ", end = " ", flush = True)
sleep(.5)
print (". ", end = " ", flush = True)
sleep(.5)
print (". ", end = " ", flush = True)
sleep(.5)
print (". Goodbye")
clientSocket.close()