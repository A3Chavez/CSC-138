from socket import *
from time import sleep

#Prepare the sever socket
serverPort = 12003
serverSocket = socket(AF_INET, SOCK_STREAM)
serverSocket.bind(('', serverPort))
serverSocket.listen(1)

#Print startup sequence
print ("Starting up server", end = " ", flush = True)
sleep(.5)
print (".", end = " ", flush = True)
sleep(.5)
print (".", end = " ", flush = True)
sleep(.5)
print (".", end = " ", flush = True)
sleep(.5)
print (". The server is ready to receive!")

while True:
	#Establish the connection
	connectionSocket, addr = serverSocket.accept()
	try:
		message = connectionSocket.recv(1024)
		print(message)

		#Parse message for requested file name
		fileName = message.split()[1]
		print(fileName)

		#Open and read file
		f = open(fileName[1:])                        
		outputdata = f.read()

		#Send one HTTP header line into socket
		connectionSocket.send(b'HTTP/1.1 200 OK\r\n\r\n')

		#Send the content of the requested file to the client
		for i in range(0, len(outputdata)):           
			connectionSocket.send((outputdata[i]).encode())
		#Close client socket
		connectionSocket.close()
	except IOError:
		#Send response message for file not found
		connectionSocket.send(b'HTTP/1.1 404 Not Found\r\n\r\n')
		connectionSocket.send(b'404 Not Found')
		#Close client socket
		connectionSocket.close()       
serverSocket.close()                                    